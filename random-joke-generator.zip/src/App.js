import "./App.scss";
import Jokes from "./components/jokes/Jokes";

function App() {
  return (
    <div>
      <Jokes />
    </div>
  );
}

export default App;
